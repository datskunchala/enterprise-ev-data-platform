# EV IoT Data Platform — 10 Department Source Files

This ZIP contains small sample source files for the following 10 departments:
1. Engineering
2. Sales
3. Service
4. Maintenance
5. Manufacturing
6. Quality
7. Supply Chain
8. Finance
9. Customer Support
10. IoT Core R&D

## Folder layout
Upload the department folders and their files under your ADLS Gen2 `source` container:

source/
  engineering/
  sales/
  service/
  maintenance/
  manufacturing/
  quality/
  supply_chain/
  finance/
  customer_support/
  iot_core_r_and_d/

The Engineering filenames preserve the current MVP conventions:
- `engineering/telemetry_001.csv`
- `engineering/vehicle_master.json`

The Service filename preserves the current MVP convention:
- `service/service_events_001.txt` (pipe-delimited)

## Upload instructions
1. Download and extract the ZIP locally.
2. Open the `EV_IoT_10_Departments_Source_Files` folder.
3. Upload the 10 department folders into the existing ADLS Gen2 container named `source`.
4. Do not upload this entire parent folder as an extra nested level. The desired path is `source/engineering/telemetry_001.csv`, not `source/EV_IoT_10_Departments_Source_Files/engineering/telemetry_001.csv`.

These are synthetic demonstration records, not real customer or vehicle data.

## Pipeline note
Your current Bronze notebook processes Engineering and Service source files. The other eight department folders are prepared for the next all-departments ingestion update; they will not automatically land in Bronze unless the notebook is expanded to process them.
